https://github.com/J2TeaM/idm-trial-reset/releases/tag/v1.0.0

Where we download the IDM from github.


Step 01 : First download the idm and install on your system.
Step 02 : IF the idm is blocked the open Trail Zip software to reset the trail then click to register the IDM.